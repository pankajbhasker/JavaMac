public interface Message {

  String SIMILAR_PASSWORD_ALERT ="Password Can't be similer to previous Password";
  String PASS_MATCHES_LAST5 ="New Password  Can't be same as last 5 Password ";
  String PASS_NULL ="Password Cant be Null";
}
