public class PassworUpdator {

  public  static void main(String arg[]){

    String previousPassword = "Password6";
    String newPassword = "Password2";

    String message = PasswordUtils.resetPassword(previousPassword,newPassword);
    System.out.println(message);

  }

}
