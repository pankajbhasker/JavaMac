import java.util.ArrayList;
import java.util.List;

public class PasswordUtils {

  private PasswordUtils utils = new PasswordUtils();


  private static List<String> listOfOldPassword = new ArrayList<>();
  private static String SUCCESS = "VALID_PASSWORD";

   private PasswordUtils(){

   }

   public PasswordUtils getUtils (){
     if(utils == null) {
       utils = new PasswordUtils();
     }
     return  utils;
   }
   public static String resetPassword (String previousPassword , String newPassword){

     listOfOldPassword.add("Password1");
     listOfOldPassword.add("Password2");
     listOfOldPassword.add("Password3");
     listOfOldPassword.add("Password4");
     listOfOldPassword.add("Password5");

    String passwordValid = isPasswordValid(previousPassword, newPassword);
    if(passwordValid.equals(SUCCESS)){
      // String firstPass =    listOfOldPassword.get(0); // something
      if(listOfOldPassword !=null && listOfOldPassword.size() >  1){
        listOfOldPassword.set(0, newPassword);
      }

      System.out.println(listOfOldPassword);
      return "Password Reset Successfully";

    }
    return "UNSUCCESSFUL";
   }

   private static String isPasswordValid(String oldPassword,String newPassword) {

     if(newPassword == null){
       return Message.PASS_NULL;
     }

    if(newPassword.equals(oldPassword)){
        return Message.SIMILAR_PASSWORD_ALERT;
    }
   else if(listOfOldPassword.contains(newPassword)){
     int index = listOfOldPassword.indexOf(newPassword);
     listOfOldPassword.set(index, newPassword);
      return Message.PASS_MATCHES_LAST5;
    }


    return SUCCESS;
   }

}
