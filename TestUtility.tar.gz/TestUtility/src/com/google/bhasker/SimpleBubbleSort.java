package com.google.bhasker;

public class SimpleBubbleSort {
  public static void main(String args[]) {
    int arr[] ={12,3,6,788,4,23,57,4};
    for(int num : arr){
      System.out.println(num);


    }
  }

}
