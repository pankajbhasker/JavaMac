package com.google.bhasker;

@FunctionalInterface
public interface IOneParamFunctionalInterface {

  public String getInputString(String input);

}
