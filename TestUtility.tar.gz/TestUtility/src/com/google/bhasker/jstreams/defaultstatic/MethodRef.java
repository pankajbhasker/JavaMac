package com.google.bhasker.jstreams.defaultstatic;

import com.google.bhasker.jstreams.AddNumber;

public class MethodRef {

  public static void main(String args[]) {
    System.out.println(AddNumber.sum(10, 20));
    System.out.println();
  }

}
