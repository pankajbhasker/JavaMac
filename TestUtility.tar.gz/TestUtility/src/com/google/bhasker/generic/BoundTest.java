package com.google.bhasker.generic;

public interface BoundTest extends Runnable{

}
