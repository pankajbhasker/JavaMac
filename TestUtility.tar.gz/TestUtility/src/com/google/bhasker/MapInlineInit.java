package com.google.bhasker;

import java.util.Map;
import java.util.stream.Stream;

public class MapInlineInit {

  public static void main(String args[]) {
    //Map<String, Integer> map =
  }
}
