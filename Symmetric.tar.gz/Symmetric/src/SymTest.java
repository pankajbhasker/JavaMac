import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.print.attribute.HashPrintJobAttributeSet;

public class SymTest {

  public static void main(String args[]) {

    String str = "{1,10} {10,1} {2,3} {3,4} {4,5} {5,4}";
  //  List<List<Integer>> listfList = new String([[1,10], [10,1], [2,3], [3,4] ,[4,5] ,[5,4]]);

    List<List<String>> numList =new ArrayList<List<String>>();

    List<String> fstrList = numList.stream().flatMap(numList1 -> numList1.stream()).collect(Collectors.toList());
    System.out.println(fstrList);
    Map<String,Integer> map = new HashMap<>();
    int count = 0;
    for (String strNum : fstrList) {
      //System.out.println(strNum);
      if(map.containsKey(strNum)){

      }
    }

  }

}
