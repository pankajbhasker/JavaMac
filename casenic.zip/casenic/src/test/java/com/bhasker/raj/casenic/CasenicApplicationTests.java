package com.bhasker.raj.casenic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasenicApplicationTests {

	@Test
	void contextLoads() {
	}

}
